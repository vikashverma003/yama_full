
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('user_name',$user->name); ?>
<?php $__env->startSection('role',$user->role); ?>
<?php $__env->startSection('content'); ?>
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">

               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="alert alert-dismissable alert-danger">
                          <?php echo $error; ?>

                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <?php if(session('status')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('status')); ?>

                      </div>
                  <?php endif; ?>
             <!--  <a href="<?php echo e(url('admin/adddoctors')); ?>" class="btn addLangBtn">
                  Add Doctors
                          </a> -->
              <h4 class="card-title"></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                         <?php 
                         $url= URL::to('/');
                         ?>
                        <tr>
                            <th width="5%">Series</th>
                            <th width="5%">User</th>
                            <th width="5%">Doctor ID</th>
                            <th width="5%">Block Status</th>
                           <!--  <th width="5%">Approved Status</th> -->
                            <th width="10%">Name</th>
                            <th width="20%">Phone Number</th>
                            <th width="20%">Email</th>
                            
                            <th width="10%">Actions</th>
                        </tr>
                      </thead>

                      <tbody>
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr>
                          <td> <?php echo $i; ?></td>

                          <?php if(!empty($user->profile_image)){ ?>
                          <td><img src="<?php echo e($url); ?>/<?php echo e($user->profile_image); ?>" alt="image" /></td>
                          <?php }else{ ?>

                             <td><img src="<?php echo e(asset('admin/images/dummy-image.jpg')); ?>" alt="image" /></td>
                           <?php } ?>
                           <td><?php echo e($user->random); ?></td>
                            <td>
                                <label class="badge <?php echo e($user->block_status == '0' ? 'badge-success' : 'badge-danger'); ?>"> <?php echo e($user->block_status == '0' ? 'UNBLOCK' : 'BLOCK'); ?></label>
                            </td>
                            <!-- <td>
                                <label class="badge <?php echo e($user->block_status == '0' ? 'badge-success' : 'badge-danger'); ?>"> <?php echo e($user->approved_status == '0' ? 'Unapproved' : 'approved'); ?></label>
                            </td> -->
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->phone_number); ?></td>
                            <td><?php echo e($user->email); ?></td>
                        
                            <td>
                              <ul class="navbar-nav">
                                <li class="nav-item dropdown d-none d-lg-flex">
                                  <a class="nav-link  nav-btn" id="actionDropdown" href="#" data-toggle="dropdown">
                                    <button class="btn btn-outline-primary">Action</button>
                                  </a>
                                   <div class="dropdown-menu navbar-dropdown" aria-labelledby="actionDropdown">
                                     <a href="<?php echo e(route('viewDoctor',$user->id)); ?>" class="dropdown-item" >View</a>
                                    <!--  <a href="<?php echo e(route('EditDoctor',$user->id)); ?>" class="dropdown-item" >Edit</a> -->
                                   <?php if($user->block_status == '0'): ?>
                                      <a href="#" class="dropdown-item" onclick="block_confirmation('<?php echo e($user->id); ?>','Block')">Block</a>
                                    <?php else: ?>
                                    <a href="#" class="dropdown-item" onclick="block_confirmation('<?php echo e($user->id); ?>','Unblock')"> Unblock</a>
                                    <?php endif; ?>


                                   <!--  <?php if($user->approved_status == '0'): ?>
                                      <a href="#" class="dropdown-item" onclick="approved_confirmation('<?php echo e($user->id); ?>','approved')">Approved</a>
                                    <?php else: ?>
                                    <a href="#" class="dropdown-item" onclick="approved_confirmation('<?php echo e($user->id); ?>','Unapproved')"> UnApproved</a>
                                    <?php endif; ?> -->

                                    
                                    <a href="#" class="dropdown-item" onclick="delete_confirmation('<?php echo e($user->id); ?>')">Delete</a>
                                  </div>
                                </li>
                              </ul>
                            </td>
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<script type="text/javascript">
  function block_confirmation(id, status)
  {
    swal({
        title: "Are you sure you want to "+status+"?",
        text: "Please ensure and then confirm",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#ab8be4",
        confirmButtonText: "Yes, "+status+" it!",
        closeOnConfirm: false
    })
   
    .then((willDelete) => {
      if (willDelete) {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
          type: 'GET',
           url: "<?php echo e(route('block_user')); ?>?user_id="+id+"&status="+status,
          success:function(data){
            if(data.success == true)
            {
              swal("Done!", data.message, "success");
            }
            else
            {
              swal("Error!", data.message, "error");
            }
            setTimeout(function(){ location.reload()}, 3000);
          }
        });
      } 
    });
  }


  function approved_confirmation(id, status)
  {
    swal({
        title: "Are you sure you want to "+status+"?",
        text: "Please ensure and then confirm",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#ab8be4",
        confirmButtonText: "Yes, "+status+" it!",
        closeOnConfirm: false
    })
   
    .then((willDelete) => {
      if (willDelete) {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
          type: 'GET',
           url: "<?php echo e(route('block_user')); ?>?user_id="+id+"&status="+status,
          success:function(data){
            if(data.success == true)
            {
              swal("Done!", data.message, "success");
            }
            else
            {
              swal("Error!", data.message, "error");
            }
            setTimeout(function(){ location.reload()}, 3000);
          }
        });
      } 
    });
  }

   function delete_confirmation(id)
  {
    swal({
        title: "Are you sure want to delete this user?",
        text: "Please ensure and then confirm",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#ab8be4",
        confirmButtonText: "Yes",
        closeOnConfirm: false
    })
   
    .then((willDelete) => {
      if (willDelete) {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
          type: 'GET',
          url: "<?php echo e(route('delete_user')); ?>?user_id="+id,
          success:function(data){
            if(data.success == true)
            {
              swal("Done!", data.message, "success");
            }
            else
            {
              swal("Error!", data.message, "error");
            }
            setTimeout(function(){ location.reload()}, 3000);
          }
        });
      } 
    });
  }
 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vinku.netsolutionindia.com/resources/views/admin/doctor/approvedDoctor.blade.php ENDPATH**/ ?>