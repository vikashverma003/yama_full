
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('user_name',$user->name); ?>
<?php $__env->startSection('role',$user->role); ?>
<?php $__env->startSection('content'); ?>
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title"> Trusted Doctor</h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th width="5%">Series</th>
                            <th width="5%">User</th>
                            <th width="5%">Status</th>
                            <th width="10%">Name</th>
                            <th width="20%">Phone Number</th>
                            <th width="20%">Email</th>
                            <!-- <th width="10%">Actions</th> -->
                        </tr>
                      </thead>

                      <tbody>
                       <?php $i=0; ?>
                        <?php $__currentLoopData = $allUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr>
                          <td> <?php echo $i; ?></td>
                          <?php if(!empty($user->profile_image)){ ?>
                          <td><img src="<?php echo e(asset($user->profile_image)); ?>" alt="image" /></td>
                          <?php }else{ ?>

                             <td><img src="<?php echo e(asset('admin/images/dummy-image.jpg')); ?>" alt="image" /></td>
                           <?php } ?>
                            <td>
                                <label class="badge <?php echo e($user->block_status == '0' ? 'badge-success' : 'badge-danger'); ?>"> <?php echo e($user->block_status == '0' ? 'UNBLOCK' : 'BLOCK'); ?></label>
                            </td>
                           
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->phone_number); ?></td>
                            <td><?php echo e($user->email); ?></td>
                        
                            <!-- <td>
                              <ul class="navbar-nav">
                                <li class="nav-item dropdown d-none d-lg-flex">
                                  <a class="nav-link  nav-btn" id="actionDropdown" href="#" data-toggle="dropdown">
                                    <button class="btn btn-outline-primary">Action</button>
                                  </a>
                                  <div class="dropdown-menu navbar-dropdown" aria-labelledby="actionDropdown">
                                     <a href="<?php echo e(route('trustedDoctor',$user->id)); ?>" class="dropdown-item" >Paid Chat Doctor</a>
                                 
                                    <!-- <div class="dropdown-divider"></div> -->
                                   
                                    <!-- <a href="#" class="dropdown-item" onclick="delete_confirmation('<?php echo e($user->id); ?>')">Delete</a> 
                                  </div>
                                </li>
                              </ul>
                            </td> -->
                        </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vinku.netsolutionindia.com/resources/views/admin/admin/trustedDoctor.blade.php ENDPATH**/ ?>