<section class="bannerSection">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <h2>Connecting Asia’s best digital talent with their next contract or freelance gig</h2>
                    <h3>Create a profile <span>»</span> Get job offers <span>»</span> Work on your terms</h3>
                    <button type="button" class="getStartedBtn">Get started »</button>

                    <h5>Looking to <a href="#" class="hireGigger">hire a Gigger </a> instead?</h5>
                    <a href="#" class="giggerVideo">
                        <img src="<?php echo e(asset('web/images/Group 492.png')); ?>" alt="">
                        <b>What is Giggers?</b>&nbsp;Find out in 30 secs.
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="giggersSection">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <h2>Harness the potential of the fast growing digital gig economy</h2>
                    <h4>Giggers.com is a talent marketplace connecting the most in demand talent with the top digital &
                        tech employers who need them for either onsite or remote work. We created Giggers because the
                        old way of work where we would expect
                        a job for life is consigned to the history books. The modern worker is driven by new
                        experiences, new environments
                        and being able to work on their terms. We wanted to give everyone the opportunity to live their
                        life and
                        manage their career in this way. </h4>
                    <br>
                    <h4>Come and join The Gig Generation.</h4>
                </div>
            </div>
        </div>
    </section>

    <section class="how-it-works">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-12">
                    <h1>Here’s how it works…</h1>

                    <ul class="work-progress">
                        <li>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/1.png')); ?>" alt="" class="numberImage">
                                    <h2>Create your profile</h2>
                                    <p>Create your profile
                                        Tell us about you, your skills, experience and how, where and when you want to
                                        work.
                                        Your life. Your choice!</p>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/01.png')); ?>" alt="" class="designImage">
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <img src="images/02.png" alt="" class="designImage">
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/2.png')); ?>" alt="" class="numberImage">
                                    <h2>Get the seal of approval </h2>
                                    <p>Get the seal of approval
                                        Giggers is a community built on trust, quality and recommendations. All profiles
                                        are
                                        first reviewed by our Talent Partners to ensure suitability for our clients and
                                        are then
                                        referenced before being approved. </p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/3.png')); ?>" alt="" class="numberImage">
                                    <h2>Go live and get gigging</h2>
                                    <p>We have lift off! Your profile is now accessible to the member companies on our
                                        marketplace. Your profile is hidden from current and previous employers of
                                        course. </p>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/03.png')); ?>" alt="" class="designImage">
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/04.png')); ?>" alt="" class="designImage">
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/4.png')); ?>" alt="" class="numberImage">
                                    <h2>Get job offers </h2>
                                    <p>Receive gig invitations from interested companies with details including the
                                        salary. It’s up to you if you accept the gig. Once you accept the employer
                                        contacts you to discuss. Build your profile, rating and reputation by completing
                                        successful gigs. </p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/5.png')); ?>" alt="" class="numberImage">
                                    <h2>Help grow the community</h2>
                                    <p>Finding a great gig is only part of the experience. As a gigger you’ll have
                                        access to our growing community <b>The Giggers Collective</b>, where you can
                                        connect, learn, get advice and gain insights from your fellow giggers. </p>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <img src="<?php echo e(asset('web/images/05.png')); ?>" alt="" class="designImage">
                                </div>
                            </div>
                        </li>
                    </ul>

                    <button type="button" class="createBtn">Create your profile »</button>
                    <h4>It’s simple and FREE!</h4>
                </div>
            </div>
        </div>
    </section>

    <section class="work-terms">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <h2>Work on your terms with our select employers</h2>
                    <h3>You’re in control. You decide where, when and how you work</h3>
                    <p>We only work with a select roster of clients who will be able to provide engaging work and
                        developmental experiences to our community of giggers. </p>
                    <p>These companies will typically be start-up's and tech & digital first organisations who need
                        specialist talent with existing relevant experience so they can make an immediate positive
                        impact.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="giggers-life">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <img src="<?php echo e(asset('web/images/Group 541.png')); ?>" alt="">
                    <h2>Live the Giggers life – find your balance, take control and give something back</h2>

                    <div class="row">
                        <div class="col-md-10 offset-md-1">
                            <h3>As a member of <strong>The Giggers Collective</strong> you are a part of an interactive
                                social
                                network. Built to
                                support every gigger, with opportunities to gain new skills, find support, mentor others
                                and
                                positively impact the wider community through partnerships with local charities and
                                social
                                enterprises. Join us and help grow the Giggers movement.</h3>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class=" box box1">
                                <h1>work</h1>
                                <h5>Work positive</h5>
                                <p>Let inspiring gigs with awesome companies find you. Choose where you want to work and
                                    do it on your terms.</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="box box2">
                                <h1>live</h1>
                                <h5>Take control</h5>
                                <p>Gigging gives you the chance to get your life back. Spend more time at home, on
                                    holiday or in the office! Find your balance.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="box box3">
                                <h1>grow</h1>
                                <h5>Lifelong learning</h5>
                                <p>Get support to continue your personal and professional development even as you move
                                    from gig-to-gig. </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="box box4">
                                <h1>give</h1>
                                <h5>Get social</h5>
                                <p>Be part of our community. Share your experiences, offer advice, receive support,
                                    build connections and pay it forward.</p>
                            </div>
                        </div>
                    </div>

                    <button type="button" class="createBtn">Get gigging today »</button>
                    <h4>Join the growing community</h4>

                    <h6>For more information read our <a href="#">FAQ</a> section or <a href="#">Contact us</a> </h6>
                </div>
            </div>
        </div>
    </section>

    <section class="reviewSection">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <img src="images/review.png" alt="">
                    <p>“Morbi velit lacus, bibendum nec est dictum, tincidunt commodo nisl. Fusce sem nibh, consectetur
                        ac eleifend a, facilisis quis dolor. Ut convallis eget odio sed sagittis. Ut dapibus ultricies
                        euismod. Pellentesque quis leo enim. “</p>
                    <h2>Brian Hardiman </h2>
                    <h3>Giggers CEO</h3>
                    <button type="button" class="createBtn">Register today »</button>
                    <h4>It’s simple and FREE!</h4>
                </div>
            </div>
        </div>
    </section><?php /**PATH C:\xampp\htdocs\giggers\resources\views/web/home/banner.blade.php ENDPATH**/ ?>