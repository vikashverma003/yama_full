<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('user_name',$user->name); ?>
<?php $__env->startSection('role',$user->role); ?>
<?php $__env->startSection('content'); ?>
        
        <div class="content-wrapper" style="min-height: 1545px;">
          <div class="card">
            <div class="card-body">
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="alert alert-dismissable alert-danger">
                          <?php echo $error; ?>

                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if(session('status')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('status')); ?>

                      </div>
                  <?php endif; ?>

                <a href="<?php echo e(url('admin/addDisease')); ?>" class="btn addLangBtn">
                  Add Disease
                          </a>
              <h4 class="card-title"></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                     <table id="order-listing" class="table">
                      <thead>
                        <tr>
                            <th width="5%">Series</th>
                            <th width="5%">Image</th>
                            <th width="5%">Name</th>
                            <th width="5%">Spanish</th>
                            <th width="10%">Actions</th>
                        </tr>
                      </thead>

                      <tbody>
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $disease; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr>
                            <td> <?php echo $i; ?> </td>
                             <?php 
                              $url= URL::to('/');
                              ?>
                            <td><label class="badge"><img src="<?php echo e($url); ?>/admin/images/doctor/<?php echo e($lag->image); ?>"></label></td>
                            <td><label class="badge"><?php echo e($lag->name); ?></label></td>
                            <td><label class="badge"><?php echo e($lag->name_es); ?></label></td>
                            <td>
                              <ul class="navbar-nav">
                                <li class="nav-item dropdown d-none d-lg-flex">
                                  <a class="nav-link  nav-btn" id="actionDropdown" href="#" data-toggle="dropdown">
                                    <button class="btn btn-outline-primary">Action</button>
                                  </a>
                                  <div class="dropdown-menu navbar-dropdown" aria-labelledby="actionDropdown">
                                    <!-- <div class="dropdown-divider"></div> -->
                                    <a href="<?php echo e(route('editdisease',$lag->id)); ?>" class="dropdown-item" >Edit</a>
                                    <a href="#" class="dropdown-item" onclick="delete_confirmation('<?php echo e($lag->id); ?>')">Delete</a>
                                  </div>
                                </li>
                              </ul>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<script type="text/javascript">

   function delete_confirmation(id)
  {
    swal({
        title: "Are you sure want to delete this user?",
        text: "Please ensure and then confirm",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#ab8be4",
        confirmButtonText: "Yes",
        closeOnConfirm: false
    })
   
    .then((willDelete) => {
      if (willDelete) {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
          type: 'GET',
          url: "<?php echo e(route('delete_disease')); ?>?user_id="+id,
          success:function(data){
            if(data.success == true)
            {
              swal("Done!", data.message, "success");
            }
            else
            {
              swal("Error!", data.message, "error");
            }
            setTimeout(function(){ location.reload()}, 3000);
          }
        });
      } 
    });
  }
 
 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vinku.netsolutionindia.com/resources/views/admin/doctor/viewDisease.blade.php ENDPATH**/ ?>