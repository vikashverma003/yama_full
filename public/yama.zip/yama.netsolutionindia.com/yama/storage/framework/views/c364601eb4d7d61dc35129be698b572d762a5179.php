
<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('user_name',$user->name); ?>
<?php $__env->startSection('role',$user->role); ?>
<?php $__env->startSection('content'); ?>
        
      <div class="content-wrapper">
          <div class="row">
             <h4 class="card-title">Add Administration</h4>
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-6 grid-margin">
                  <div class="card">
                    <div class="card-body">
                      <form action="<?php echo e(url('admin/createAdministaration')); ?>" method="POST" class="forms-sample" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Name</label>
                          <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Enter Name" required="">
                             </div>

                          <div class="form-group">
                          <label for="exampleInputEmail1">Name Spanish</label>
                          <input type="text" name="name_es" class="form-control" id="exampleInputEmail1" placeholder="Enter Name" required="">
                             </div>
                         <button type="submit" class="btn btn-success mr-2">Submit</button>
                         
                     </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vinku.netsolutionindia.com/resources/views/admin/admin/addadministration.blade.php ENDPATH**/ ?>