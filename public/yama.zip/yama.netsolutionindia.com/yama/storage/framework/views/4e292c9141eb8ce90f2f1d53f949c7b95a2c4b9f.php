<?php $__env->startSection('title', __('messages.header_titles.HOME')); ?>

<?php $__env->startSection('content'); ?>
 
<?php echo $__env->make('web.home.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- New Section -->
<section class="new-how-it-works">
  
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\giggers\resources\views/web/home/index.blade.php ENDPATH**/ ?>