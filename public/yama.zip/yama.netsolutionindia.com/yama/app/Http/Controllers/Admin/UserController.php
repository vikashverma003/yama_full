<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use App\Models\Role;
use App\Models\Group;
use App\Models\Chatrequest;
use App\User;
use URL;
use Hash;
use Mail;
//use Conekta\Conekta;
use DB;
class UserController extends Controller
{
    protected $groupObj;
    public function __construct(Group $group)
    {
         $this->groupObj   =$group;
        
    }
    

    /**
     * Login page
     */
    public function term(){
     return view('admin.admin.term', ['title' => 'Term and condition']);
    }

    public function privacy(){
     return view('admin.admin.privacy', ['title' => 'Privacy Policy']);
    }

    public function index(){
      if (Auth::check()) {
        return redirect('admin/dashboard');
      }
      Auth::logout();

  
      return view('admin.login', ['title' => 'Login Page']);
    }


    /**
     * Check user Detail
     */

    public function login(Request $request){
         
      $request->validate([
          'email' => 'required|email|exists:users,email',
          'password' => 'required|min:6',
      ]);

      if (!Auth::check()) {
        $email=$request->get('email');
        $password=$request->get('password');
  
        if (Auth::attempt(['email' => $email, 'password' => $password, 'role' =>'admin','account_status'=>'active'])) {
          return redirect('admin/dashboard');
      }else{
        return redirect('admin/login')->with('error', 'Login credential is not valid ') ;
      }
      }
  }
  
  public function logout(){
    Auth::logout();
    return redirect(\URL::previous());
  }

  public function users(Request $request){
        $user=Auth::user();
        $allUser = User::where('role',config('constants.role.USER'))->where('account_status','0')->get();
        return view('admin.admin.viewUser', ['title' => 'Users','user'=>$user, 'allUser'=>$allUser]);
     
  }
  public function group(Request $request){
        $user=Auth::user();
        $group=Group::get();
        $allUser = User::where('role',config('constants.role.USER'))->where('account_status','0')->get();
        return view('admin.admin.viewGroup', ['title' => 'Users','user'=>$user, 'group'=>$group]);   
  }

  public function addGroup(Request $request){

     $user=Auth::user();
     return view('admin.admin.addGroup', ['title' => 'Add Services','user'=>$user]);
  }

  public function editGroup(Request $request,$id){
    $user=Auth::user();
    $data=Group::where('id',$id)->first();
    return view('admin.admin.editGroup', ['title' => 'Add Services','user'=>$user,'data'=>$data]);
  }

  public function createGroup(Request $request){

    if ($request->hasFile('image')) {
            $file = request()->file('image');
            $ext=$file->getClientOriginalExtension();
            $imagename = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $imagename);
            }

      $url= URL::to('/');
      $groupImage=$url.'/admin/images/doctor/'.$imagename;
      $createdUser=$this->groupObj->creategroup([
            'heading'     =>  $request->food_name??null,
            'restaurants' =>  $request->restaurants??null,
            'description' =>  $request->description??null,
            'image'       =>  $groupImage??null,
        ]);
       return redirect('admin/group')->with('status','Group has been added Successfully.');
  }

  public function updateGroup(Request $request){
       if ($request->hasFile('image')) {
            $file = request()->file('image');
            $ext=$file->getClientOriginalExtension();
            $imagename = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $imagename);
            }
            if(!empty($imagename)){
              $url= URL::to('/');
              $groupImage=$url.'/admin/images/doctor/'.$imagename;
            }else{
              $reqInfo=Group::where('id',$request->id)->first();
              $groupImage=$reqInfo->image;
          }
      Group::where('id',$request->id)->update([
                'heading'     =>  $request->food_name??null,
                'restaurant_id' =>  $request->restaurants??null,
                'description' =>  $request->description??null,
                'image'       =>  $groupImage??null,
                       
            ]);
        return redirect('admin/group')->with('status','Group has been updated Successfully.');
  }



}
