<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use App\Models\Role;
use App\Models\General;
use App\Models\Billing;
use App\Models\Deposit;
use App\Models\Language;
use App\Models\Cfdi;
use App\Models\Fiscal;
use App\Models\Medicalchat;
use App\Models\Medicalpro;
use App\Models\Doctorstatus;
use App\Models\Disease;
use App\User;
use Hash;
class DoctorsController extends Controller
{
  protected $userObj;
  protected $genralObj;
  protected $billingObj;
  protected $cfdiObj;
  protected $depositObj;
  protected $fiscalObj;
  protected $medicalchatObj;
  protected $medicalproObj;
  protected $doctorstatusObj;
  protected $diseaseObj;

    public function __construct(User $user,General $general,Billing $billing,Cfdi $cfdi,Deposit $deposit,Fiscal $fiscal,Medicalchat $medicalchat,Medicalpro $medicalpro,Doctorstatus $doctorstatus,Disease $disease)
    {
        $this->userObj        =$user;
        $this->genralObj      =$general;
        $this->billingObj     =$billing;
        $this->cfdiObj        =$cfdi;
        $this->depositObj     =$deposit;
        $this->fiscalObj      =$fiscal;
        $this->medicalproObj  =$medicalpro;
        $this->medicalchatObj =$medicalchat;
        $this->doctorstatusObj=$doctorstatus;
        $this->diseaseObj     =$disease;
        
    }

    /**
     * Login page
     */

    public function index(){
      if (Auth::check()) {
        return redirect('admin/viewDoctors');
      }
      Auth::logout();

      return view('admin.login', ['title' => 'Login Page']);
    }

    public function viewDoctors(Request $request){
        $user=Auth::user();
        $getdoctor= User::where(['role'=>'doctor','account_status'=>'0','approved_status'=>'0'])->get();
      
        return view('admin.doctor.viewDoctor', ['title' => 'View Doctor','user'=>$user,'doctors'=>$getdoctor]);
    }


    public function approveddoctors(Request $request){
        $user=Auth::user();
        $getdoctor= User::where(['role'=>'doctor','account_status'=>'0','approved_status'=>'1'])->get();
      
        return view('admin.doctor.approvedDoctor', ['title' => 'Approved Doctor','user'=>$user,'doctors'=>$getdoctor]);
    }

    
    
    public function add(Request $request){
       $user=Auth::user();
        $language=Language::get();
        $disease=Disease::get();
       return view('admin.doctor.addDoctor', ['title' => 'Add Doctor','user'=>$user,'language'=>$language,'disease'=>$disease]);
    }

    public function addDoctor(Request $request){
             // dd($request->all());       
     try{
            
            $emailCount= User::where(['email'=>$request->email])->first();
            if(!empty($emailCount)){
            return redirect('admin/viewDoctors')->with('status','Email Already Exist');
            }else{

            //die($createdUser);
             
            if ($request->hasFile('professional_document')) {
            $file = request()->file('professional_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
                 
            $professional_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $professional_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
                
            }
            }


            if ($request->hasFile('professional_title')) {
            $file = request()->file('professional_title');

            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){

                $professional_title = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $file->move('admin/images/doctor', $professional_title);

            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

            if ($request->hasFile('official_identification')) {
            $file = request()->file('official_identification');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
                 $official_identification = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                  $file->move('admin/images/doctor', $official_identification);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }


            if ($request->hasFile('curp_document')) {
            $file = request()->file('curp_document');
           $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
                $curp_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $file->move('admin/images/doctor', $curp_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

            if ($request->hasFile('rfc_document')) {
            $file = request()->file('rfc_document');

            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               $rfc_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $rfc_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

             if ($request->hasFile('address_document')) {
            $file = request()->file('address_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
              $address_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $address_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

             if ($request->hasFile('bank_document')) {
            $file = request()->file('bank_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
              $bank_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $bank_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

             if ($request->hasFile('seal_certificate')) {
            $file = request()->file('seal_certificate');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               $seal_certificate = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $seal_certificate);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

            if ($request->hasFile('electronic_signature')) {
            $file = request()->file('electronic_signature');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $electronic_signature = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $electronic_signature);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

             if ($request->hasFile('chatprofile_photo')) {
            $file = request()->file('chatprofile_photo');
            $chatprofile_photo = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $chatprofile_photo);
            }

            if ($request->hasFile('chatdegrees_documents')) {
            $file = request()->file('chatdegrees_documents');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $chatdegrees_documents = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $chatdegrees_documents);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

            if ($request->hasFile('profile_photo')) {
            $file = request()->file('profile_photo');
            $profile_photo = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move(public_path(), $profile_photo);
            }

             if ($request->hasFile('b_degree_document')) {
            $file = request()->file('b_degree_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
             $b_degree_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $b_degree_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

            if ($request->hasFile('m_speciality_documents')) {
            $file = request()->file('m_speciality_documents');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
             $m_speciality_documents = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $m_speciality_documents);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            
            }

            if ($request->hasFile('s_medical_speciality_document')) {
            $file = request()->file('s_medical_speciality_document');

            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $s_medical_speciality_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $s_medical_speciality_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            
            }

            if ($request->hasFile('master_name_document')) {
            $file = request()->file('master_name_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $master_name_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $master_name_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            
            }

            if ($request->hasFile('phd_document')) {
            $file = request()->file('phd_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $phd_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $phd_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }

            $createdUser=$this->userObj->createDoctor([
                'email'         =>  $request->email??null,
                'phone_number'  =>  $request->phone_number??null,
                'disease'       =>  $request->disease??null,
                'profile_image' =>  $profile_photo??null,
                'rating'        =>  '5',
                'random'        =>  mt_rand(100000, 999999),
            ]);
      
            $createdGeneral=$this->genralObj->createGeneral([
                'professional_card'        =>  $request->gnprofessional_card??null,
                'professional_document'    =>  $professional_document??null,
                'professional_title'       =>  $professional_title??null,
                'official_identification'  =>  $official_identification??null,
                'curp'                     =>  $request->curp??null,
                'curp_document'            =>  $curp_document??null,
                'rfc'                      =>  $request->rfc??null,
                'rfc_document'             =>  $rfc_document??null,
                'proof_address'            =>  $request->proof_address??null,
                'ssa_registration'         =>  $request->ssa_registration??null,
                'address_document'         =>  $address_document??null,
                'user_id'                  =>  $createdUser['id']

            ]);

             $createdBilling=$this->billingObj->createBilling([
                'company_name'             =>  $request->company_name??null,
                'name_rfc'                 =>  $request->name_rfc??null,
                'address'                  =>  $request->address??null,
                'number'                   =>  $request->number??null,
                'municipality'             =>  $request->municipality??null,
                'state'                    =>  $request->state??null,
                'zipcode'                  =>  $request->zipcode??null,
                'country'                  =>  $request->country??null,
                'colonia'                  =>  $request->colonia??null,
                'telephone'                =>  $request->telephone??null,
                'mail'                     =>  $request->mail??null,
                'user_id'                  =>  $createdUser['id']
            ]);

               $createdCfdi=$this->cfdiObj->createCfdi([
                'purchase_goods'            =>  $request->purchase_goods ??null,
                'returns'                   =>  $request->returns??null,
                'accessories'               =>  $request->accessories??null,
                'general_expenses'          =>  $request->general_expenses??null,
                'telephone_communications'  =>  $request->telephone_communications??null,
                'satellite_communications'  =>  $request->satellite_communications??null,
                'hospital_fees'             =>  $request->hospital_fees??null,
                'handicap'                  =>  $request->handicap??null,
                'insurance_premiums'        =>  $request->insurance_premiums??null,
                'educational_services'      =>  $request->educational_services??null,
                'medical_expenses'          =>  $request->medical_expenses??null,
                'be_defined'                =>  $request->be_defined??null,
                'user_id'                   =>  $createdUser['id']
            ]);

               

                 $createdCfdi=$this->depositObj->createDeposit([
                'bank_account'             =>  $request->bank_account ??null,
                'bank_document'            =>  $bank_document??null,
                'rfc'                      =>  $request->rfc ??null,
                'account_type'             =>  $request->account_type??null,
                'type_account'             =>  $request->type_account??null,
                'complete_name'            =>  $request->complete_name??null,
                'company_name'             =>  $request->company_name??null,
                'interbank_type'           =>  $request->interbank_type??null,
                'bank_name'                =>  $request->bank_name??null,
                'user_id'                  =>  $createdUser['id']
            ]);


           

             $createdCfdi=$this->fiscalObj->createFiscal([
                'seal_certificate'         =>  $seal_certificate ??null,
                'electronic_signature'     =>  $electronic_signature??null,
                'password'                 =>  $request->password??null,
                'user_id'                  =>  $createdUser['id']
            ]);


           

                 $createMedicalchat=$this->medicalchatObj->createMedicalchat([
                'fullname'              =>  $request->chatfullname ??null,
                'professional_card'     =>  $request->chatprofessional_card??null,
                'language'              =>  $request->chatlanguage??null,
                'short_description'     =>  $request->chatshort_description??null,
                'experience'            =>  $request->chatexperience??null,
                'degrees'               =>  $request->chatdegrees??null,
                'workplace'             =>  $request->chatworkplace??null,
                'profile_photo'         =>  $chatprofile_photo??null,
                'degrees_documents'     =>  $chatdegrees_documents??null,
                'user_id'               =>  $createdUser['id']
            ]);



                 


                 $createMedicalpro=$this->medicalproObj->createMedicalpro([
                'fullname'              =>  $request->fullname ??null,
                'professional_card'     =>  $request->proprofessional_card??null,
                'language'              =>  $request->language??null,
                'short_description'     =>  $request->short_description??null,
                'experience'            =>  $request->experience??null,
                'university'            =>  $request->university??null,
                'workplace'             =>  $request->workplace??null,
                'working_hours'         =>  $request->working_hours??null,
                'average_price'         =>  $request->average_price??null,
                'b_degree'              =>  $request->b_degree??null,

                'b_degree_document'     =>  $b_degree_document??null,
                'm_speciality'          =>  $request->m_speciality??null,
                'm_speciality_documents'=>  $m_speciality_documents??null,
                's_medical_speciality'  =>  $request->s_medical_speciality??null,
                's_medical_speciality_document'=>  $s_medical_speciality_document??null,
                'master_name'            =>  $request->master_name??null,
                'master_name_document'   =>  $master_name_document??null,

                'phd_name'               =>  $request->phd_name??null,
                'phd_document'           =>  $phd_document??null,
                'address'                =>  $request->address??null,
                'number'                 =>  $request->number??null,

                'colonia'                =>  $request->colonia??null,
                'municipality'           =>  $request->municipality??null,
                'state'                  =>  $request->state??null,
                'country'                =>  $request->country??null,
                'zipcode'                =>  $request->zipcode??null,
                'recognition'            =>  $request->recognition??null,
                'price'                  =>  $request->price??null,
                'day'                    =>  $request->day??null,
                'awards'                 =>  $request->awards??null,
                'hours'                  =>  $request->hours??null,
                'courses'                =>  $request->courses??null,
                'contact_number'         =>  $request->contact_number??null,
                'profile_photo'          =>  $profile_photo??null,
                'user_id'                =>  $createdUser['id']
            ]);

            $createDoctorstatus=$this->doctorstatusObj->createDoctorstatus([
                'pre_registration'       =>  $request->pre_registration ??null,
                'presentation'           =>  $request->presentation??null,
                'interview'              =>  $request->interview??null,
                'contract'               =>  $request->contract??null,
                'photo_registration'     =>  $request->photo_registration??null,
                'activation'             =>  $request->activation??null,
                'document_registration'  =>  $request->document_registration??null,
                'user_id'                =>  $createdUser['id']
            ]);

            //  User::where('id',$createdUser['id'])->update([
            //         'profile_photo'          =>  $profile_photo??null
            // ]);


            
        if(!empty($createdUser['id'])){
          return redirect('admin/viewDoctors')->with('status','Doctor Added Successfully');
        }

    }

    } catch (\PDOException $e) {
 
    }
    }

    public function UpdateDoctor(Request $request){
       
     try{
            
            // $emailCount= User::where(['email'=>$request->email])->first();
            // if(!empty($emailCount)){
            // return redirect('admin/viewDoctors')->with('status','Email Already Exist');
            // }else{

            //die($createdUser);
             
            if ($request->hasFile('professional_document')) {
            $file = request()->file('professional_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
                 
            $professional_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $professional_document);
            }else{

                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
                
            }
            }


            if ($request->hasFile('professional_title')) {
            $file = request()->file('professional_title');

            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){

                $professional_title = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $file->move('admin/images/doctor', $professional_title);

            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=General::where('user_id',$request->id)->first();
                $professional_title=$data->professional_title;
            }


            if ($request->hasFile('official_identification')) {
            $file = request()->file('official_identification');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
                 $official_identification = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                  $file->move('admin/images/doctor', $official_identification);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=General::where('user_id',$request->id)->first();
                $official_identification=$data->official_identification;
            }


            if ($request->hasFile('curp_document')) {
            $file = request()->file('curp_document');
           $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
                $curp_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $file->move('admin/images/doctor', $curp_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=General::where('user_id',$request->id)->first();
                $curp_document=$data->curp_document;
            }


            if ($request->hasFile('rfc_document')) {
            $file = request()->file('rfc_document');

            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               $rfc_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $rfc_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=General::where('user_id',$request->id)->first();
                $rfc_document=$data->rfc_document;
            }

             if ($request->hasFile('address_document')) {
            $file = request()->file('address_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
              $address_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $address_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                 $data=General::where('user_id',$request->id)->first();
                 $address_document=$data->address_document;
            }

             if ($request->hasFile('bank_document')) {
            $file = request()->file('bank_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
              $bank_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $bank_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=Deposit::where('user_id',$request->id)->first();
               $bank_document= $data->bank_document;
            }

             if ($request->hasFile('seal_certificate')) {
            $file = request()->file('seal_certificate');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               $seal_certificate = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $seal_certificate);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=Fiscal::where('user_id',$request->id)->first();
                $seal_certificate=$data->seal_certificate;
            }

            if ($request->hasFile('electronic_signature')) {
            $file = request()->file('electronic_signature');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $electronic_signature = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $electronic_signature);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=Fiscal::where('user_id',$request->id)->first();
                $electronic_signature=$data->electronic_signature;
            }



             if ($request->hasFile('chatprofile_photo')) {
            $file = request()->file('chatprofile_photo');
            $chatprofile_photo = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $chatprofile_photo);
            }else{
                $data=Medicalchat::where('user_id',$request->id)->first();
                $chatprofile_photo=$data->profile_photo;
            }

            if ($request->hasFile('chatdegrees_documents')) {
            $file = request()->file('chatdegrees_documents');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $chatdegrees_documents = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $chatdegrees_documents);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=Medicalchat::where('user_id',$request->id)->first();
                $chatdegrees_documents=$data->chatdegrees_documents;
            }
             
             
            if ($request->hasFile('profile_photo')) {
            $file = request()->file('profile_photo');
            $profile_photo = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move(public_path(), $profile_photo);
            }else{
                $data=User::where('id',$request->id)->first();
                $profile_photo=$data->profile_image;
            }

             if ($request->hasFile('b_degree_document')) {
            $file = request()->file('b_degree_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
             $b_degree_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $b_degree_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=Medicalpro::where('user_id',$request->id)->first();
                $b_degree_document=$data->b_degree_document;
            }

            if ($request->hasFile('m_speciality_documents')) {
            $file = request()->file('m_speciality_documents');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
             $m_speciality_documents = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $m_speciality_documents);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            
            }else{
                $data=Medicalpro::where('user_id',$request->id)->first();
                $m_speciality_documents=$data->m_speciality_documents;
            }

            if ($request->hasFile('s_medical_speciality_document')) {
            $file = request()->file('s_medical_speciality_document');

            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $s_medical_speciality_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $s_medical_speciality_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            
            }else{
                $data=Medicalpro::where('user_id',$request->id)->first();
                $s_medical_speciality_document=$data->s_medical_speciality_document;
            }

            if ($request->hasFile('master_name_document')) {
            $file = request()->file('master_name_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $master_name_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $master_name_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            
            }else{
                $data=Medicalpro::where('user_id',$request->id)->first();
                $master_name_document=$data->master_name_document;
            }

            if ($request->hasFile('phd_document')) {
            $file = request()->file('phd_document');
            $ext=$file->getClientOriginalExtension();
            if($ext == 'pdf' or $ext== 'doc' or $ext== 'docx' or $ext== 'xls' or $ext== 'xlsx' or $ext== 'csv' or $ext== 'txt' or $ext== 'rtf' or $ext== 'html'){
               
            $phd_document = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $phd_document);
            }else{
                return redirect('admin/viewDoctors')->with('status','Please Use following format for documents pdf,doc,docx,xls,xlsx,csv,txt,rtf,html ');
            }
            }else{
                $data=Medicalpro::where('user_id',$request->id)->first();
                $phd_document=$data->phd_document;
            }

            // $createdUser=$this->userObj->createDoctor([
            //     'email'         =>  $request->email??null,
            //     'phone_number'  =>  $request->phone_number??null,
            //     'disease'       =>  $request->disease??null,
            //     'profile_image' =>  $profile_photo??null,
            //     'random'        =>  mt_rand(100000, 999999),
            // ]);


             $data=User::where('id',$request->id)->update([
                    'email'         =>  $request->email??null,
                    'phone_number'  =>  $request->phone_number??null,
                    'disease'       =>  $request->disease??null,
                    'profile_image' =>  $profile_photo??null,
              ]);
      
            // $createdGeneral=$this->genralObj->createGeneral([
            //     'professional_card'        =>  $request->gnprofessional_card??null,
            //     'professional_document'    =>  $professional_document??null,
            //     'professional_title'       =>  $professional_title??null,
            //     'official_identification'  =>  $official_identification??null,
            //     'curp'                     =>  $request->curp??null,
            //     'curp_document'            =>  $curp_document??null,
            //     'rfc'                      =>  $request->rfc??null,
            //     'rfc_document'             =>  $rfc_document??null,
            //     'proof_address'            =>  $request->proof_address??null,
            //     'ssa_registration'         =>  $request->ssa_registration??null,
            //     'address_document'         =>  $address_document??null,
            //     'user_id'                  =>  $createdUser['id']

            // ]);


            
            $data=General::where('user_id',$request->id)->update([
                'professional_card'        =>  $request->gnprofessional_card??null,
                'professional_document'    =>  $professional_document??null,
                'professional_title'       =>  $professional_title??null,
                'official_identification'  =>  $official_identification??null,
                'curp'                     =>  $request->curp??null,
                'curp_document'            =>  $curp_document??null,
                'rfc'                      =>  $request->rfc??null,
                'rfc_document'             =>  $rfc_document??null,
                'proof_address'            =>  $request->proof_address??null,
                'ssa_registration'         =>  $request->ssa_registration??null,
                'address_document'         =>  $address_document??null,
              ]);


            //  $createdBilling=$this->billingObj->createBilling([
            //     'company_name'             =>  $request->company_name??null,
            //     'name_rfc'                 =>  $request->name_rfc??null,
            //     'address'                  =>  $request->address??null,
            //     'number'                   =>  $request->number??null,
            //     'municipality'             =>  $request->municipality??null,
            //     'state'                    =>  $request->state??null,
            //     'zipcode'                  =>  $request->zipcode??null,
            //     'country'                  =>  $request->country??null,
            //     'colonia'                  =>  $request->colonia??null,
            //     'telephone'                =>  $request->telephone??null,
            //     'mail'                     =>  $request->mail??null,
            //     'user_id'                  =>  $createdUser['id']
            // ]);


             $data=Billing::where('user_id',$request->id)->update([
                'company_name'             =>  $request->company_name??null,
                'name_rfc'                 =>  $request->name_rfc??null,
                'address'                  =>  $request->address??null,
                'number'                   =>  $request->number??null,
                'municipality'             =>  $request->municipality??null,
                'state'                    =>  $request->state??null,
                'zipcode'                  =>  $request->zipcode??null,
                'country'                  =>  $request->country??null,
                'colonia'                  =>  $request->colonia??null,
                'telephone'                =>  $request->telephone??null,
                'mail'                     =>  $request->mail??null,
              ]);

             

            //    $createdCfdi=$this->cfdiObj->createCfdi([
            //     'purchase_goods'            =>  $request->purchase_goods ??null,
            //     'returns'                   =>  $request->returns??null,
            //     'accessories'               =>  $request->accessories??null,
            //     'general_expenses'          =>  $request->general_expenses??null,
            //     'telephone_communications'  =>  $request->telephone_communications??null,
            //     'satellite_communications'  =>  $request->satellite_communications??null,
            //     'hospital_fees'             =>  $request->hospital_fees??null,
            //     'handicap'                  =>  $request->handicap??null,
            //     'insurance_premiums'        =>  $request->insurance_premiums??null,
            //     'educational_services'      =>  $request->educational_services??null,
            //     'medical_expenses'          =>  $request->medical_expenses??null,
            //     'be_defined'                =>  $request->be_defined??null,
            //     'user_id'                   =>  $createdUser['id']
            // ]);

               
               $data=Cfdi::where('user_id',$request->id)->update([
                'purchase_goods'            =>  $request->purchase_goods ??null,
                'returns'                   =>  $request->returns??null,
                'accessories'               =>  $request->accessories??null,
                'general_expenses'          =>  $request->general_expenses??null,
                'telephone_communications'  =>  $request->telephone_communications??null,
                'satellite_communications'  =>  $request->satellite_communications??null,
                'hospital_fees'             =>  $request->hospital_fees??null,
                'handicap'                  =>  $request->handicap??null,
                'insurance_premiums'        =>  $request->insurance_premiums??null,
                'educational_services'      =>  $request->educational_services??null,
                'medical_expenses'          =>  $request->medical_expenses??null,
                'be_defined'                =>  $request->be_defined??null,
              ]);

               

            //      $createdCfdi=$this->depositObj->createDeposit([
            //     'bank_account'             =>  $request->bank_account ??null,
            //     'bank_document'            =>  $bank_document??null,
            //     'rfc'                      =>  $request->rfc ??null,
            //     'account_type'             =>  $request->account_type??null,
            //     'type_account'             =>  $request->type_account??null,
            //     'complete_name'            =>  $request->complete_name??null,
            //     'company_name'             =>  $request->company_name??null,
            //     'interbank_type'           =>  $request->interbank_type??null,
            //     'bank_name'                =>  $request->bank_name??null,
            //     'user_id'                  =>  $createdUser['id']
            // ]);

            $data=Deposit::where('user_id',$request->id)->update([
                'bank_account'             =>  $request->bank_account ??null,
                'bank_document'            =>  $bank_document??null,
                'rfc'                      =>  $request->rfc ??null,
                'account_type'             =>  $request->account_type??null,
                'type_account'             =>  $request->type_account??null,
                'complete_name'            =>  $request->complete_name??null,
                'company_name'             =>  $request->company_name??null,
                'interbank_type'           =>  $request->interbank_type??null,
                'bank_name'                =>  $request->bank_name??null,
              ]);


           

            //  $createdCfdi=$this->fiscalObj->createFiscal([
            //     'seal_certificate'         =>  $seal_certificate ??null,
            //     'electronic_signature'     =>  $electronic_signature??null,
            //     'password'                 =>  $request->password??null,
            //     'user_id'                  =>  $createdUser['id']
            // ]);


              $data=Fiscal::where('user_id',$request->id)->update([
                'seal_certificate'         =>  $seal_certificate ??null,
                'electronic_signature'     =>  $electronic_signature??null,
                'password'                 =>  $request->password??null,
              ]);


           

           // $createMedicalchat=$this->medicalchatObj->createMedicalchat([
           //      'fullname'              =>  $request->chatfullname ??null,
           //      'professional_card'     =>  $request->chatprofessional_card??null,
           //      'language'              =>  $request->chatlanguage??null,
           //      'short_description'     =>  $request->chatshort_description??null,
           //      'experience'            =>  $request->chatexperience??null,
           //      'degrees'               =>  $request->chatdegrees??null,
           //      'workplace'             =>  $request->chatworkplace??null,
           //      'profile_photo'         =>  $chatprofile_photo??null,
           //      'degrees_documents'     =>  $chatdegrees_documents,
           //      'user_id'               =>  $createdUser['id']
           //  ]);


         $data=Medicalchat::where('user_id',$request->id)->update([
                'fullname'              =>  $request->chatfullname ??null,
                'professional_card'     =>  $request->chatprofessional_card??null,
                'language'              =>  $request->chatlanguage??null,
                'short_description'     =>  $request->chatshort_description??null,
                'experience'            =>  $request->chatexperience??null,
                'degrees'               =>  $request->chatdegrees??null,
                'workplace'             =>  $request->chatworkplace??null,
                'profile_photo'         =>  $chatprofile_photo??null,
                'degrees_documents'     =>  $chatdegrees_documents,
              ]);

                 


            //      $createMedicalpro=$this->medicalproObj->createMedicalpro([
            //     'fullname'              =>  $request->fullname ??null,
            //     'professional_card'     =>  $request->proprofessional_card??null,
            //     'language'              =>  $request->language??null,
            //     'short_description'     =>  $request->short_description??null,
            //     'experience'            =>  $request->experience??null,
            //     'university'            =>  $request->university??null,
            //     'workplace'             =>  $request->workplace??null,
            //     'working_hours'         =>  $request->working_hours??null,
            //     'average_price'         =>  $request->average_price??null,
            //     'b_degree'              =>  $request->b_degree??null,

            //     'b_degree_document'     =>  $b_degree_document??null,
            //     'm_speciality'          =>  $request->m_speciality??null,
            //     'm_speciality_documents'=>  $m_speciality_documents??null,
            //     's_medical_speciality'  =>  $request->s_medical_speciality??null,
            //     's_medical_speciality_document'=>  $s_medical_speciality_document??null,
            //     'master_name'            =>  $request->master_name??null,
            //     'master_name_document'   =>  $master_name_document??null,

            //     'phd_name'               =>  $request->phd_name??null,
            //     'phd_document'           =>  $phd_document??null,
            //     'address'                =>  $request->address??null,
            //     'number'                 =>  $request->number??null,

            //     'colonia'                =>  $request->colonia??null,
            //     'municipality'           =>  $request->municipality??null,
            //     'state'                  =>  $request->state??null,
            //     'country'                =>  $request->country??null,
            //     'zipcode'                =>  $request->zipcode??null,
            //     'recognition'            =>  $request->recognition??null,
            //     'price'                  =>  $request->price??null,
            //     'day'                    =>  $request->day??null,
            //     'awards'                 =>  $request->awards??null,
            //     'hours'                  =>  $request->hours??null,
            //     'courses'                =>  $request->courses??null,
            //     'contact_number'         =>  $request->contact_number??null,
            //     'profile_photo'          =>  $profile_photo??null,
            //     'user_id'                =>  $createdUser['id']
            // ]);

                 

            $data=Medicalpro::where('user_id',$request->id)->update([
                'fullname'              =>  $request->fullname ??null,
                'professional_card'     =>  $request->proprofessional_card??null,
                'language'              =>  $request->language??null,
                'short_description'     =>  $request->short_description??null,
                'experience'            =>  $request->experience??null,
                'university'            =>  $request->university??null,
                'workplace'             =>  $request->workplace??null,
                'working_hours'         =>  $request->working_hours??null,
                'average_price'         =>  $request->average_price??null,
                'b_degree'              =>  $request->b_degree??null,

                'b_degree_document'     =>  $b_degree_document??null,
                'm_speciality'          =>  $request->m_speciality??null,
                'm_speciality_documents'=>  $m_speciality_documents??null,
                's_medical_speciality'  =>  $request->s_medical_speciality??null,
                's_medical_speciality_document'=>  $s_medical_speciality_document??null,
                'master_name'            =>  $request->master_name??null,
                'master_name_document'   =>  $master_name_document??null,

                'phd_name'               =>  $request->phd_name??null,
                'phd_document'           =>  $phd_document??null,
                'address'                =>  $request->address??null,
                'number'                 =>  $request->number??null,

                'colonia'                =>  $request->colonia??null,
                'municipality'           =>  $request->municipality??null,
                'state'                  =>  $request->state??null,
                'country'                =>  $request->country??null,
                'zipcode'                =>  $request->zipcode??null,
                'recognition'            =>  $request->recognition??null,
                'price'                  =>  $request->price??null,
                'day'                    =>  $request->day??null,
                'awards'                 =>  $request->awards??null,
                'hours'                  =>  $request->hours??null,
                'courses'                =>  $request->courses??null,
                'contact_number'         =>  $request->contact_number??null,
                'profile_photo'          =>  $profile_photo??null,
              ]);

            // $createDoctorstatus=$this->doctorstatusObj->createDoctorstatus([
            //     'pre_registration'       =>  $request->pre_registration ??null,
            //     'presentation'           =>  $request->presentation??null,
            //     'interview'              =>  $request->interview??null,
            //     'contract'               =>  $request->contract??null,
            //     'photo_registration'     =>  $request->photo_registration??null,
            //     'activation'             =>  $request->activation??null,
            //     'document_registration'  =>  $request->document_registration??null,
            //     'user_id'                =>  $createdUser['id']
            // ]);

             $data=Doctorstatus::where('user_id',$request->id)->update([
                'pre_registration'       =>  $request->pre_registration ??null,
                'presentation'           =>  $request->presentation??null,
                'interview'              =>  $request->interview??null,
                'contract'               =>  $request->contract??null,
                'photo_registration'     =>  $request->photo_registration??null,
                'activation'             =>  $request->activation??null,
                'document_registration'  =>  $request->document_registration??null,
            ]);


            
       // if($data){
          return redirect('admin/viewDoctors')->with('status','Doctor Updated Successfully');
       // }

   

    } catch (\PDOException $e) {
 
    }

    }

    public function viewDoctor(Request $request,$id){
        $user=Auth::user();
         $getdoctor= User::where(['id'=>$id])->with('general')->with('billing')->with('deposit')->with('fiscal')->with('medicalpro')->with('medicalchat')->with('cfdi')->with('diseases')->first();
       return view('admin.doctor.singleDoctor', ['title' => 'Single Doctor','user'=>$user,'doctor'=>$getdoctor]);
    }
    public function disease(Request $request){

       $user=Auth::user();
       $disease = Disease::get();
       return view('admin.doctor.viewDisease', ['title' => 'View Disease','user'=>$user,'disease'=>$disease]);

    }
    public function addDisease(Request $request){
     
       $user=Auth::user();
       return view('admin.doctor.addDisease', ['title' => 'Add Doctor','user'=>$user]);

    }

    public function createDisease(Request $request){
        if ($request->hasFile('image')) {
            $file = request()->file('image');
            $ext=$file->getClientOriginalExtension();
            $image = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $image);
            }
       $createDoctorstatus=$this->diseaseObj->createDisease([
                'name'       =>  $request->name??null,
                'name_es'    =>  $request->name_es??null,
                'image'      =>  $image??null,
                'description'=> $request->description??null,
                'description_es'=> $request->description_es??null,
               
            ]);
       return redirect('admin/disease')->with('status','Disease Added Successfully');
    }

    public function editdisease(Request $request, $id){
       $user=Auth::user();
       $disease= Disease::where(['id'=>$id])->first();

       return view('admin.doctor.editdisease', ['title' => 'Add Doctor','user'=>$user,'disease'=>$disease]);
    }

    public function EditDoctor(Request $request,$id){
        $user=Auth::user();
        $language=Language::get();
        $disease=Disease::get();
         $getdoctor= User::where(['id'=>$id])->with('general')->with('billing')->with('deposit')->with('fiscal')->with('medicalpro')->with('doctorstatus')->with('medicalchat')->with('cfdi')->with('diseases')->first();
         //print_r($getdoctor->toArray());
       return view('admin.doctor.editDoctor', ['title' => 'Update Doctor','user'=>$user,'language'=>$language,'disease'=>$disease,'doctor'=>$getdoctor]);
    }

    public function updateDeaseas(Request $request){
        $ans= Disease::where(['id'=>$request->id])->first();
        if ($request->hasFile('image')) {
            $file = request()->file('image');
            $ext=$file->getClientOriginalExtension();
            $image = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $file->move('admin/images/doctor', $image);
            }else{
                $image=$ans->image;
            }
           
        Disease::where('id',$request->id)->update([
                    'name'        => $request->name,
                    'name_es'     => $request->name_es,
                    'description' => $request->description,
                    'description_es' => $request->description_es,
                    'image'       => $image,
                    'updated_at'  => new \DateTime
            ]);
        return redirect('admin/disease')->with('status','Disease Updated Successfully');
    }

    public function delete_disease(Request $request){
       $result=\DB::table('disease')->where('id',$request->user_id)->delete();
      if($result){
         return response()->json(['success' => true,'message' => 'Disease Deleted Successfully']);
      }
    }



}
