<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Trusted extends Model
{
    protected $table = 'trusted';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'patient_id', 'doctor_id','status'
    ];


    public function createTrusted($data){
      
         $createdUser= self::create(
            [
                'patient_id'     =>  $data['patient_id']??null,
                'doctor_id'      =>  $data['doctor_id']??null,
                'status'         =>  '1',
            ]
        );

       return $createdUser;
    }

    public function trustedUser()
    {
        return $this->hasOne(\App\User::class,"id","doctor_id");
    }
}
