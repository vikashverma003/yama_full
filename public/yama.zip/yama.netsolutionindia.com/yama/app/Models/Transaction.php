<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $table = 'transaction_history';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'transaction_id', 'status','amount','currency','code','patient_id','doctor_id','request_id'
    ];


    public function createdTrs($data){

        $createdUser= self::create(
            [
                'transaction_id'  =>  $data['transaction_id']??null,
                'status'          =>  $data['status']??null,
                'amount'          =>  $data['amount']??null,
                'currency'        =>  $data['currency']??null,
                'code'            =>  $data['code']??null,
                'patient_id'      =>  $data['patient_id']??null,
                'doctor_id'       =>  $data['doctor_id']??null,
                'request_id'      =>  $data['request_id']??null,
            ]
        );

       return $createdUser;
    }
   
    public function patient()
    {
        return $this->hasOne(\App\User::class,"id","patient_id");
    }

    public function doctor()
    {
        return $this->hasOne(\App\User::class,"id","doctor_id");
    }

}
