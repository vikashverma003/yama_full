<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NotificationMedication extends Model
{
    protected $table = 'notification_medication';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'medication_id', 'day','time','status'
    ];


}
