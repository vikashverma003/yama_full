<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medicalpro extends Model
{
    protected $table = 'medical_pro';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'fullname', 'professional_card','language','short_description','experience','university','workplace','working_hours','average_price','b_degree','b_degree_document','m_speciality','m_speciality_documents','s_medical_speciality','s_medical_speciality_document','master_name','master_name_document','phd_name','phd_document','address','number','colonia','municipality','state','country','zipcode','recognition','price','awards','day','hours','courses','contact_number','profile_photo'
    ];

    public function createMedicalpro($data){    
      
        $createMedicalpro= self::create([
                'fullname'              =>  $data['fullname']??null,
                'professional_card'     =>  $data['professional_card']??null,
                'language'              =>  $data['language']??null,
                'short_description'     =>  $data['short_description']??null,
                'experience'            =>  $data['experience']??null,
                'university'            =>  $data['university']??null,
                'workplace'             =>  $data['workplace']??null,
                'working_hours'         =>  $data['working_hours']??null,
                'average_price'         =>  $data['average_price']??null, 
                'b_degree'              =>  $data['b_degree']??null, 
                'b_degree_document'     =>  $data['b_degree_document']??null, 
                'm_speciality'          =>  $data['m_speciality']??null, 
                'm_speciality_documents'=>  $data['m_speciality_documents']??null, 
                's_medical_speciality'  =>  $data['s_medical_speciality']??null, 
                's_medical_speciality_document'=>  $data['s_medical_speciality_document']??null, 
                'master_name'           =>  $data['master_name']??null, 
                'master_name_document'  =>  $data['master_name_document']??null, 
                'phd_name'              =>  $data['phd_name']??null, 
                'phd_document'          =>  $data['phd_document']??null, 
                'address'               =>  $data['address']??null, 
                'number'                =>  $data['number']??null, 
                'colonia'               =>  $data['colonia']??null, 
                'municipality'          =>  $data['municipality']??null, 
                'state'                 =>  $data['state']??null, 
                'country'               =>  $data['country']??null, 
                'zipcode'               =>  $data['zipcode']??null, 
                'recognition'           =>  $data['recognition']??null, 
                'price'                 =>  $data['price']??null, 
                'day'                   =>  $data['day']??null, 
                'awards'                =>  $data['awards']??null, 
                'hours'                 =>  $data['hours']??null, 
                'courses'               =>  $data['courses']??null,
                'contact_number'        =>  $data['contact_number']??null, 
                'profile_photo'         =>  $data['profile_photo']??null, 
                'user_id'               =>  $data['user_id']??null, 
            ]
        );
       return $createMedicalpro;
    }
}
