<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Fiscal extends Model
{
    protected $table = 'fiscal_keys';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'seal_certificate', 'electronic_signature','password'
    ];

    public function createFiscal($data){
      
        $createFiscal= self::create([
                'seal_certificate'       =>  $data['seal_certificate']??null,
                'electronic_signature'   =>  $data['electronic_signature']??null,
                'password'               =>  $data['password']??null,
                'user_id'                =>  $data['user_id']??null,
            ]);
        
       return $createFiscal;
    }
}
