<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Userimage extends Model
{
    protected $table = 'usersimage';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'upload_id', 'selfie','upload_profile'
    ];
}
