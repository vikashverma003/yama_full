<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Disease extends Model
{
    protected $table = 'disease';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'created_at', 'updated_at','image','description'
    ];

    public function createDisease($data){
          
         $createdUsers= self::create(
            [
                'name'         =>  $data['name']??null,
                'name_es'      =>  $data['name_es']??null,
                'image'        =>  $data['image']??null,
                'description'  =>  $data['description']??null,
                'description_es'=>  $data['description_es']??null,
            ]
        );

       return $createdUsers;
    }
    
}
