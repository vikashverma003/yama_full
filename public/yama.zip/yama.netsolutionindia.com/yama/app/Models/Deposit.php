<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Deposit extends Model
{
    protected $table = 'deposit_data';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'bank_account', 'bank_document','rfc','account_type','type_account','complete_name','company_name','interbank_type','bank_name'
    ];

    public function createDeposit($data){
      
        $createDeposit= self::create([
                'bank_account'              =>  $data['bank_account']??null,
                'bank_document'             =>  $data['bank_document']??null,
                'rfc'                       =>  $data['rfc']??null,
                'account_type'              =>  $data['account_type']??null,
                'type_account'              =>  $data['type_account']??null,
                'complete_name'             =>  $data['complete_name']??null,
                'company_name'              =>  $data['company_name']??null,
                'interbank_type'            =>  $data['interbank_type']??null,
                'bank_name'                 =>  $data['bank_name']??null,
                'user_id'                   =>  $data['user_id']??null
            ]
        );
        
       return $createDeposit;
    }
}
