<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medicalchat extends Model
{
    protected $table = 'medical_chat';
     /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'fullname', 'professional_card','language','short_description','experience','degrees','degrees_documents','workplace','profile_photo'
    ];

    public function createMedicalchat($data){
      
        $createMedicalchat= self::create([
                'fullname'              =>  $data['fullname']??null,
                'professional_card'     =>  $data['professional_card']??null,
                'language'              =>  $data['language']??null,
                'short_description'     =>  $data['short_description']??null,
                'experience'            =>  $data['experience']??null,
                'degrees'               =>  $data['degrees']??null,
                'workplace'             =>  $data['workplace']??null,
                'degrees_documents'     =>  $data['degrees_documents']??null,
                'profile_photo'         =>  $data['profile_photo']??null,
                'user_id'               =>  $data['user_id']??null, 
            ]
        );
        
       return $createMedicalchat;
    }
}
