<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\User as UserResource;
use App\Http\Resources\Userinfo as UserResourceinfo;
use Hash;

class User extends Authenticatable
{
    use HasApiTokens,Notifiable;
  
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','device_token','role','account_status','phone_code','phone_number','otp','disease','profile_image','random','rating','time_zone'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];



    public function createUser($data){
      
        $createdUser= self::create(
            [
                'name'         =>  $data['name']??null,
                'email'        =>  $data['email']??null,
                'role'         =>  'patient',
                'phone_code'   =>  $data['phone_code']??null,
                'phone_number' =>  $data['phone_number']??null,
                'device_token' =>  $data['device_token']??null,
                'otp'          =>  $data['otp'],
                'time_zone'    =>  $data['time_zone'],
                'rating'       =>  '5'
                
            ]
        );

       return $this->user_resource($createdUser);
    }

    public function createDoctor($data){
           
         $createdUsers= self::create(
            [
                'email'        =>  $data['email']??null,
                'role'         =>  'doctor',
                'disease'      =>  $data['disease']??null,
                'phone_number' =>  $data['phone_number'],
                'profile_image'=>  $data['profile_image'],
                'rating'       =>  '5',
                'random'       =>  $data['random'],
                
            ]
        );

       return $createdUsers;
    }
    
    public function user_resource($user){

        return new UserResource($user);
    }

    public function userinfo()
    {
        return $this->hasOne(\App\Models\Userinfo::class,"user_id","id");
    }
    
    public function userimage()
    {
        return $this->hasOne(\App\Models\Userimage::class,"user_id","id");
    }

    public function general()
    {
        return $this->hasOne(\App\Models\General::class,"user_id","id");
    }

    public function billing()
    {
        return $this->hasOne(\App\Models\Billing::class,"user_id","id");
    }

    public function deposit()
    {
        return $this->hasOne(\App\Models\Deposit::class,"user_id","id");
    }

    public function fiscal()
    {
        return $this->hasOne(\App\Models\Fiscal::class,"user_id","id");
    }

    public function medicalpro()
    {
        return $this->hasOne(\App\Models\Medicalpro::class,"user_id","id");
    }

    public function medicalchat()
    {
        return $this->hasOne(\App\Models\Medicalchat::class,"user_id","id");
    }

    public function cfdi()
    {
        return $this->hasOne(\App\Models\Cfdi::class,"user_id","id");
    }
    public function doctorstatus()
    {
        return $this->hasOne(\App\Models\Doctorstatus::class,"user_id","id");
    }

    public function diseases()
    {
        return $this->hasOne(\App\Models\Disease::class,"id","disease");
    }

    public function chatRequest()
    {
        return $this->hasOne(\App\Models\ChatRequest::class,"doctor_id","id");
    }
    

    
    
    

    public function createPassportToken($user){
        return $user->createToken('dayNightApp')->accessToken;
    }
}
