@extends('web.layouts.app')
@section('title', __('messages.header_titles.HOME'))

@section('content')
 
@include('web.home.banner')
  <!-- New Section -->
<section class="new-how-it-works">
  
</section>

@endsection
