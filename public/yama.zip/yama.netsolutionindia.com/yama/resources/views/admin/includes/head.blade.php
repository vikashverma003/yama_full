 
  <!-- plugins:css -->
  <link rel="stylesheet" href="{{asset('admin/node_modules/mdi/css/materialdesignicons.min.css')}}" />
  <link rel="stylesheet" href="{{asset('admin/node_modules/simple-line-icons/css/simple-line-icons.css')}}" />
  <link rel="stylesheet" href="{{asset('admin/node_modules/flag-icon-css/css/flag-icon.min.css')}}" />
  <link rel="stylesheet" href="{{asset('admin/node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css')}}" />
  <link rel="stylesheet" type="text/css" href="{{asset('admin/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css')}}" />

  <link rel="stylesheet" type="text/css" href="{{asset('admin/node_modules/sweetalert2/dist/sweetalert2.min.css')}}" />


    <link rel="stylesheet" href="{{asset('admin/node_modules/select2/dist/css/select2.min.css')}}" />
  <link rel="stylesheet" href="{{asset('admin/node_modules/select2-bootstrap-theme/dist/select2-bootstrap.min.css')}}" />
  <link rel="stylesheet" href="{{asset('admin/node_modules/font-awesome/css/font-awesome.min.css')}}" />

   <link rel="stylesheet" href="{{asset('admin/node_modules/icheck/skins/all.css')}}" />
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="{{asset('admin/css/style.css')}}" />
  <!-- endinject -->
  <link rel="shortcut icon" href="{{asset('admin/images/favicon.png')}}" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />